package com.idoctortech.idoctor.uProfile;

public class P {

    int user_id;
    String first_name;
    String second_name;
    String last_name;
    String user_email;
    String user_dob;
    String user_gender;
    String user_insurance;
    String user_type;
    String user_city_id;
    String user_image;
    String user_phone;
    String user_bload;
    String user_wight;
    String user_height;
    String user_smoking;
    String user_alcohol;

    public P() {
    }

    public P(int user_id, String first_name, String second_name, String last_name, String user_email, String user_dob, String user_gender, String user_insurance, String user_type, String user_city_id, String user_image, String user_phone, String user_bload, String user_wight, String user_height, String user_smoking, String user_alcohol) {
        this.user_id = user_id;
        this.first_name = first_name;
        this.second_name = second_name;
        this.last_name = last_name;
        this.user_email = user_email;
        this.user_dob = user_dob;
        this.user_gender = user_gender;
        this.user_insurance = user_insurance;
        this.user_type = user_type;
        this.user_city_id = user_city_id;
        this.user_image = user_image;
        this.user_phone = user_phone;
        this.user_bload = user_bload;
        this.user_wight = user_wight;
        this.user_height = user_height;
        this.user_smoking = user_smoking;
        this.user_alcohol = user_alcohol;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getSecond_name() {
        return second_name;
    }

    public void setSecond_name(String second_name) {
        this.second_name = second_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_dob() {
        return user_dob;
    }

    public void setUser_dob(String user_dob) {
        this.user_dob = user_dob;
    }

    public String getUser_gender() {
        return user_gender;
    }

    public void setUser_gender(String user_gender) {
        this.user_gender = user_gender;
    }

    public String getUser_insurance() {
        return user_insurance;
    }

    public void setUser_insurance(String user_insurance) {
        this.user_insurance = user_insurance;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getUser_city_id() {
        return user_city_id;
    }

    public void setUser_city_id(String user_city_id) {
        this.user_city_id = user_city_id;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public String getUser_bload() {
        return user_bload;
    }

    public void setUser_bload(String user_bload) {
        this.user_bload = user_bload;
    }

    public String getUser_wight() {
        return user_wight;
    }

    public void setUser_wight(String user_wight) {
        this.user_wight = user_wight;
    }

    public String getUser_height() {
        return user_height;
    }

    public void setUser_height(String user_height) {
        this.user_height = user_height;
    }

    public String getUser_smoking() {
        return user_smoking;
    }

    public void setUser_smoking(String user_smoking) {
        this.user_smoking = user_smoking;
    }

    public String getUser_alcohol() {
        return user_alcohol;
    }

    public void setUser_alcohol(String user_alcohol) {
        this.user_alcohol = user_alcohol;
    }
}
